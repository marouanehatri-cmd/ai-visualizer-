import express, { Request, Response } from 'express';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3000;

// Body parser with 50mb limit for high-res base64 images
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Server-side Gemini client initialization with mandatory User-Agent
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

export interface MediumPreset {
  id: string;
  name: string;
  category: string;
  defaultAspect: '1:1' | '16:9' | '4:3' | '3:4' | '9:16';
  promptTemplate: string;
}

export const MEDIUM_PRESETS: Record<string, MediumPreset> = {
  coffee_mug: {
    id: 'coffee_mug',
    name: 'Ceramic Coffee Mug',
    category: 'Drinkware & Tabletop',
    defaultAspect: '1:1',
    promptTemplate:
      'A premium ceramic coffee mug placed on a clean minimalist light oak cafe table with soft morning natural window light and subtle steam rising. The exact product logo, typography, and visual branding from the input image is photorealistically printed and seamlessly wrapped around the ceramic surface of the mug with realistic specular highlights and glaze reflections.',
  },
  billboard: {
    id: 'billboard',
    name: 'Metropolitan Billboard',
    category: 'Out of Home (OOH)',
    defaultAspect: '16:9',
    promptTemplate:
      'A massive towering metropolitan outdoor billboard elevated above an urban avenue at dusk. Cinematic blue hour sky, illuminated by warm focused overhead billboard spotlights, city traffic light trails below. The billboard poster prominently showcases the exact product packaging and visual brand identity with razor-sharp typography and high-contrast commercial layout.',
  },
  t_shirt: {
    id: 't_shirt',
    name: 'Heavyweight Cotton T-Shirt',
    category: 'Apparel & Streetwear',
    defaultAspect: '3:4',
    promptTemplate:
      'A stylish model wearing an oversized heavyweight vintage-washed black cotton streetwear t-shirt in a sunlit industrial loft studio. The exact product graphic, emblem, and brand logo from the input image is crisp and authentically screen-printed onto the chest with natural fabric wrinkles, soft textile weave texture, and realistic matte ink absorption.',
  },
  tote_bag: {
    id: 'tote_bag',
    name: 'Canvas Tote Bag',
    category: 'Accessories & Retail',
    defaultAspect: '1:1',
    promptTemplate:
      'An aesthetic unbleached natural organic canvas tote bag hanging gracefully on a wooden wall peg inside a boutique design shop. The product branding and primary artwork from the input image is cleanly screen-printed onto the canvas, showing realistic coarse woven cotton texture and gentle draped fabric folds.',
  },
  subway_poster: {
    id: 'subway_poster',
    name: 'Subway Lightbox Poster',
    category: 'Transit Advertising',
    defaultAspect: '16:9',
    promptTemplate:
      'An ultra-modern illuminated backlit transit lightbox poster on the tiled wall of a minimalist high-speed underground subway station. Gentle cinematic passenger motion blur in the background, cool architectural lighting. The advertisement vividly displays the exact product design and brand typography in commercial clarity.',
  },
  storefront: {
    id: 'storefront',
    name: 'Luxury Storefront Window',
    category: 'Retail Architecture',
    defaultAspect: '4:3',
    promptTemplate:
      'A high-end luxury boutique display window along an upscale metropolitan shopping avenue. The product is elegantly spotlighted on a sculpted travertine pedestal behind pristine reflective plate glass, with subtle boutique interior ambiance and architectural mood lighting.',
  },
};

// Health check endpoint (for CI/CD and deployment verification)
app.get('/api/health', (_req: Request, res: Response) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    hasApiKey: Boolean(process.env.GEMINI_API_KEY),
    service: 'nanomock-studio-api',
  });
});

// Analyze product image endpoint to extract brand identity and suggest tailored prompts
app.post('/api/analyze-product', async (req: Request, res: Response) => {
  try {
    const { imageBase64, mimeType = 'image/jpeg' } = req.body;

    if (!imageBase64) {
      return res.status(400).json({ error: 'Missing imageBase64 in request body' });
    }

    const cleanBase64 = imageBase64.replace(/^data:image\/[a-zA-Z0-9+.-]+;base64,/, '');

    const prompt = `Analyze this product image thoroughly for a commercial mockup generator.
Return a structured JSON with:
1. "productName": Identified or descriptive product name (e.g. "Solstice Specialty Coffee Bag")
2. "productCategory": Category of the product
3. "visualIdentity": Concise description of key visual identity elements (colors, logos, materials, typography, distinctive shapes)
4. "dominantColors": Array of 3-5 hex or descriptive color names (e.g. ["#1A1A1A", "#D4AF37", "#FFFFFF"])
5. "recommendedTagline": A short punchy marketing tagline suitable for billboards and posters
6. "mediumPrompts": An object with tailored prompt descriptions for:
   - "coffee_mug": Specific prompt placing this exact product branding onto a ceramic mug
   - "billboard": Specific prompt for an urban billboard featuring this product
   - "t_shirt": Specific prompt for an apparel item featuring this product
   - "tote_bag": Specific prompt for a canvas tote featuring this product
   - "subway_poster": Specific prompt for transit advertising featuring this product
   - "storefront": Specific prompt for a boutique storefront showcase

Return ONLY valid JSON matching this structure without markdown code fences.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: {
        parts: [
          {
            inlineData: {
              data: cleanBase64,
              mimeType,
            },
          },
          { text: prompt },
        ],
      },
      config: {
        responseMimeType: 'application/json',
      },
    });

    const text = response.text || '{}';
    let parsedData;
    try {
      parsedData = JSON.parse(text);
    } catch {
      const match = text.match(/\{[\s\S]*\}/);
      parsedData = match ? JSON.parse(match[0]) : {};
    }

    return res.json({ success: true, analysis: parsedData });
  } catch (error: any) {
    console.error('Error analyzing product:', error);
    return res.status(500).json({
      error: error.message || 'Failed to analyze product image',
    });
  }
});

// Single frame visualization endpoint using Gemini Nano Banana (image-to-image consistency)
app.post('/api/visualize', async (req: Request, res: Response) => {
  try {
    const {
      imageBase64,
      mimeType = 'image/jpeg',
      mediumId = 'coffee_mug',
      customPrompt,
      aspectRatio = '1:1',
      quality = '1K',
      brandDetails,
      lightingStyle = 'studio',
    } = req.body;

    if (!imageBase64) {
      return res.status(400).json({ error: 'Missing imageBase64 in request body' });
    }

    const cleanBase64 = imageBase64.replace(/^data:image\/[a-zA-Z0-9+.-]+;base64,/, '');

    // Formulate consistency instructions
    const preset = MEDIUM_PRESETS[mediumId];
    const baseMediumDescription = customPrompt || (preset ? preset.promptTemplate : `A marketing medium of ${mediumId}`);

    let lightingContext = '';
    if (lightingStyle === 'golden_hour') {
      lightingContext = ' Warm golden hour sunlight with rich amber rim lighting and soft elongated shadows.';
    } else if (lightingStyle === 'cyber_dusk') {
      lightingContext = ' Dramatic neon twilight illumination with cool cyan and magenta ambient reflections.';
    } else if (lightingStyle === 'minimal_studio') {
      lightingContext = ' Clean high-key Scandinavian studio lighting with diffuse shadows and crisp white highlights.';
    } else if (lightingStyle === 'cinematic_moody') {
      lightingContext = ' Moody cinematic low-key directional lighting with high micro-contrast.';
    }

    const consistencyPrompt = `You are an elite product visualization and commercial advertising photographer.
INPUT: An image of a specific product.
TASK: Place the EXACT product, its packaging, and its distinctive visual branding (logos, typography, colors, patterns, and physical materials) into a commercial marketing visual:

MARKETING MEDIUM & SCENE:
${baseMediumDescription}${lightingContext}
${brandDetails ? `CRITICAL PRODUCT IDENTITY DETAILS TO MAINTAIN CONSISTENTLY:\n${brandDetails}` : ''}

CONSISTENCY DIRECTIVES:
1. Product Fidelity: The product's shape, logo emblems, brand typography, and color palette must remain completely consistent with the source image.
2. Material Integration: Accurately simulate physical interaction between product/brand graphics and the medium surface (e.g., curvature wrapping on mugs, ink absorption on fabric, backlight glow on billboard displays).
3. Commercial Realism: Seamless perspective, realistic shadows, environmental reflections, high photographic realism, zero artifacts.`;

    // Attempt generation with gemini-nano-banana-2.1 first
    const primaryModel = 'gemini-nano-banana-2.1';
    const fallbackModel = 'gemini-3.1-flash-lite-image';

    let generatedImageUrl: string | null = null;
    let usedModel = primaryModel;
    let modelNote = '';

    try {
      const response = await ai.models.generateContent({
        model: primaryModel,
        contents: {
          parts: [
            {
              inlineData: {
                data: cleanBase64,
                mimeType,
              },
            },
            {
              text: consistencyPrompt,
            },
          ],
        },
        config: {
          imageConfig: {
            aspectRatio: aspectRatio as any,
            imageSize: quality === '2K' ? '2K' : '1K',
          },
        },
      });

      for (const part of response.candidates?.[0]?.content?.parts ?? []) {
        if (part.inlineData?.data) {
          const imgMime = part.inlineData.mimeType || 'image/png';
          generatedImageUrl = `data:${imgMime};base64,${part.inlineData.data}`;
          break;
        }
      }
    } catch (primaryErr: any) {
      console.warn(`Primary model ${primaryModel} failed: ${primaryErr.message}. Trying fallback ${fallbackModel}...`);
      usedModel = fallbackModel;
      modelNote = primaryErr.message;

      // Fallback to gemini-3.1-flash-lite-image
      const fallbackResponse = await ai.models.generateContent({
        model: fallbackModel,
        contents: {
          parts: [
            {
              inlineData: {
                data: cleanBase64,
                mimeType,
              },
            },
            {
              text: consistencyPrompt,
            },
          ],
        },
      });

      for (const part of fallbackResponse.candidates?.[0]?.content?.parts ?? []) {
        if (part.inlineData?.data) {
          const imgMime = part.inlineData.mimeType || 'image/png';
          generatedImageUrl = `data:${imgMime};base64,${part.inlineData.data}`;
          break;
        }
      }
    }

    if (!generatedImageUrl) {
      return res.status(500).json({
        error: 'Model completed execution but did not produce an image part in the response candidates.',
        usedModel,
      });
    }

    return res.json({
      success: true,
      imageUrl: generatedImageUrl,
      mediumId,
      aspectRatio,
      usedModel,
      note: modelNote || undefined,
    });
  } catch (error: any) {
    console.error('Error generating visualization:', error);
    return res.status(500).json({
      error: error.message || 'Failed to generate visualization',
    });
  }
});

// Batch frame generator for an entire campaign suite
app.post('/api/campaign-suite', async (req: Request, res: Response) => {
  try {
    const {
      imageBase64,
      mimeType = 'image/jpeg',
      mediumIds = ['coffee_mug', 'billboard', 't_shirt'],
      brandDetails,
      lightingStyle = 'studio',
    } = req.body;

    if (!imageBase64 || !Array.isArray(mediumIds) || mediumIds.length === 0) {
      return res.status(400).json({ error: 'Missing imageBase64 or mediumIds array' });
    }

    const cleanBase64 = imageBase64.replace(/^data:image\/[a-zA-Z0-9+.-]+;base64,/, '');

    const results: Array<{
      mediumId: string;
      imageUrl?: string;
      error?: string;
      aspectRatio: string;
    }> = [];

    // Process sequentially or in controlled batches to avoid quota spikes
    for (const mediumId of mediumIds) {
      const preset = MEDIUM_PRESETS[mediumId];
      const baseDesc = preset ? preset.promptTemplate : `Commercial advertisement in a ${mediumId} setting`;
      const aspect = preset ? preset.defaultAspect : '1:1';

      const prompt = `Preserving complete product fidelity with the provided product image:
Place this exact product, logo, packaging colors, and typography into:
${baseDesc}
Ensure photorealistic integration, correct perspective wrapping, and authentic commercial photography lighting. Maintain consistent brand appearance across this marketing suite.`;

      try {
        let frameUrl: string | null = null;
        try {
          const resp = await ai.models.generateContent({
            model: 'gemini-nano-banana-2.1',
            contents: {
              parts: [
                { inlineData: { data: cleanBase64, mimeType } },
                { text: prompt },
              ],
            },
            config: {
              imageConfig: {
                aspectRatio: aspect as any,
                imageSize: '1K',
              },
            },
          });
          for (const part of resp.candidates?.[0]?.content?.parts ?? []) {
            if (part.inlineData?.data) {
              frameUrl = `data:${part.inlineData.mimeType || 'image/png'};base64,${part.inlineData.data}`;
              break;
            }
          }
        } catch {
          // Fallback to flash-lite-image
          const respFallback = await ai.models.generateContent({
            model: 'gemini-3.1-flash-lite-image',
            contents: {
              parts: [
                { inlineData: { data: cleanBase64, mimeType } },
                { text: prompt },
              ],
            },
          });
          for (const part of respFallback.candidates?.[0]?.content?.parts ?? []) {
            if (part.inlineData?.data) {
              frameUrl = `data:${part.inlineData.mimeType || 'image/png'};base64,${part.inlineData.data}`;
              break;
            }
          }
        }

        if (frameUrl) {
          results.push({ mediumId, imageUrl: frameUrl, aspectRatio: aspect });
        } else {
          results.push({ mediumId, error: 'No image returned', aspectRatio: aspect });
        }
      } catch (err: any) {
        results.push({ mediumId, error: err.message, aspectRatio: aspect });
      }
    }

    return res.json({ success: true, frames: results });
  } catch (error: any) {
    console.error('Error generating campaign suite:', error);
    return res.status(500).json({ error: error.message || 'Failed to generate campaign suite' });
  }
});

// Frontend Vite integration (Full-stack runtime)
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    // Dynamic import to avoid loading Vite in production
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // Production static serving
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`NanoMock Studio Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
