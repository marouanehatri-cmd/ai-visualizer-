import React from 'react';
import { MediumId, AspectRatio, LightingStyle, MediumPreset } from '../types.ts';
import { MEDIUM_PRESETS } from '../data/mediumPresets.ts';
import { Coffee, Maximize2, Shirt, ShoppingBag, Train, Store, Sparkles, Sliders } from 'lucide-react';

interface MediumSelectorProps {
  selectedMediumId: MediumId;
  setSelectedMediumId: (id: MediumId) => void;
  customPrompt: string;
  setCustomPrompt: (prompt: string) => void;
  aspectRatio: AspectRatio;
  setAspectRatio: (ratio: AspectRatio) => void;
  lightingStyle: LightingStyle;
  setLightingStyle: (style: LightingStyle) => void;
  quality: '1K' | '2K';
  setQuality: (quality: '1K' | '2K') => void;
  onSynthesize: () => void;
  isGenerating: boolean;
  selectedMediumPreset: MediumPreset | undefined;
}

const MEDIUM_ICONS: Record<MediumId, React.ReactNode> = {
  coffee_mug: <Coffee className="w-4 h-4" />,
  billboard: <Maximize2 className="w-4 h-4" />,
  t_shirt: <Shirt className="w-4 h-4" />,
  tote_bag: <ShoppingBag className="w-4 h-4" />,
  subway_poster: <Train className="w-4 h-4" />,
  storefront: <Store className="w-4 h-4" />,
  custom: <Sliders className="w-4 h-4" />,
};

export const MediumSelector: React.FC<MediumSelectorProps> = ({
  selectedMediumId,
  setSelectedMediumId,
  customPrompt,
  setCustomPrompt,
  aspectRatio,
  setAspectRatio,
  lightingStyle,
  setLightingStyle,
  quality,
  setQuality,
  onSynthesize,
  isGenerating,
  selectedMediumPreset,
}) => {
  return (
    <div className="bg-white dark:bg-stone-900 rounded-xl border border-stone-200 dark:border-stone-800 p-6 shadow-xs">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-stone-100 dark:border-stone-800">
        <div>
          <h2 className="text-base font-semibold text-stone-900 dark:text-stone-100 font-display">
            02. Marketing Medium & Atmosphere
          </h2>
          <div className="flex items-center gap-2 text-xs text-stone-500 dark:text-stone-400 mt-1">
            <span>Commercial Presets</span>
            <span aria-hidden="true">·</span>
            <span>Custom Prompts</span>
            <span aria-hidden="true">·</span>
            <span>Atmospheric Lighting</span>
          </div>
        </div>

        {/* Quality Resolution Switch */}
        <div className="flex items-center gap-2">
          <span className="text-xs text-stone-500">Resolution:</span>
          <div className="inline-flex rounded-lg border border-stone-200 dark:border-stone-700 p-0.5 bg-stone-50 dark:bg-stone-800">
            <button
              onClick={() => setQuality('1K')}
              className={`px-2.5 py-1 text-xs font-medium rounded-md transition-all ${
                quality === '1K'
                  ? 'bg-white dark:bg-stone-900 text-stone-900 dark:text-stone-100 shadow-xs'
                  : 'text-stone-600 dark:text-stone-400 hover:text-stone-900'
              }`}
            >
              1K Commercial
            </button>
            <button
              onClick={() => setQuality('2K')}
              className={`px-2.5 py-1 text-xs font-medium rounded-md transition-all ${
                quality === '2K'
                  ? 'bg-white dark:bg-stone-900 text-stone-900 dark:text-stone-100 shadow-xs'
                  : 'text-stone-600 dark:text-stone-400 hover:text-stone-900'
              }`}
            >
              2K Nano Banana
            </button>
          </div>
        </div>
      </div>

      {/* Medium Presets Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-7 gap-3 mt-6">
        {MEDIUM_PRESETS.map((preset) => {
          const isSelected = selectedMediumId === preset.id;
          return (
            <button
              key={preset.id}
              onClick={() => {
                setSelectedMediumId(preset.id);
                setAspectRatio(preset.defaultAspect);
              }}
              className={`p-3 rounded-lg border text-left transition-all flex flex-col justify-between h-24 ${
                isSelected
                  ? 'border-stone-900 dark:border-stone-100 bg-stone-900 text-white dark:bg-stone-100 dark:text-stone-950 shadow-sm'
                  : 'border-stone-200 dark:border-stone-800 bg-stone-50/50 dark:bg-stone-950 hover:border-stone-300 dark:hover:border-stone-700 text-stone-900 dark:text-stone-100'
              }`}
            >
              <div className="flex items-center justify-between w-full">
                <span
                  className={
                    isSelected ? 'text-white dark:text-stone-950' : 'text-stone-500 dark:text-stone-400'
                  }
                >
                  {MEDIUM_ICONS[preset.id]}
                </span>
                <span
                  className={`text-[10px] font-mono tabular-nums ${
                    isSelected ? 'text-stone-300 dark:text-stone-700' : 'text-stone-400'
                  }`}
                >
                  {preset.defaultAspect}
                </span>
              </div>
              <div>
                <p className="text-xs font-semibold leading-tight line-clamp-1">{preset.name}</p>
                <p
                  className={`text-[10px] truncate mt-0.5 ${
                    isSelected ? 'text-stone-300 dark:text-stone-600' : 'text-stone-500'
                  }`}
                >
                  {preset.category}
                </p>
              </div>
            </button>
          );
        })}

        {/* Custom Medium Button */}
        <button
          onClick={() => setSelectedMediumId('custom')}
          className={`p-3 rounded-lg border text-left transition-all flex flex-col justify-between h-24 ${
            selectedMediumId === 'custom'
              ? 'border-stone-900 dark:border-stone-100 bg-stone-900 text-white dark:bg-stone-100 dark:text-stone-950 shadow-sm'
              : 'border-stone-200 dark:border-stone-800 bg-stone-50/50 dark:bg-stone-950 hover:border-stone-300 dark:hover:border-stone-700 text-stone-900 dark:text-stone-100'
          }`}
        >
          <div className="flex items-center justify-between w-full">
            <span
              className={
                selectedMediumId === 'custom'
                  ? 'text-white dark:text-stone-950'
                  : 'text-stone-500 dark:text-stone-400'
              }
            >
              {MEDIUM_ICONS.custom}
            </span>
            <span
              className={`text-[10px] font-mono tabular-nums ${
                selectedMediumId === 'custom' ? 'text-stone-300 dark:text-stone-700' : 'text-stone-400'
              }`}
            >
              Any
            </span>
          </div>
          <div>
            <p className="text-xs font-semibold leading-tight">Custom Scene</p>
            <p
              className={`text-[10px] truncate mt-0.5 ${
                selectedMediumId === 'custom' ? 'text-stone-300 dark:text-stone-600' : 'text-stone-500'
              }`}
            >
              Freeform Prompt
            </p>
          </div>
        </button>
      </div>

      {/* Atmospheric Lighting & Aspect Ratio Controls */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6 mt-6 pt-5 border-t border-stone-100 dark:border-stone-800">
        {/* Lighting Selector */}
        <div className="md:col-span-6 space-y-1.5">
          <label className="text-xs font-medium text-stone-700 dark:text-stone-300">
            Lighting & Atmosphere Environment:
          </label>
          <div className="grid grid-cols-2 gap-2">
            {[
              { id: 'studio', label: 'Studio Minimal', hint: 'Diffuse clean high-key' },
              { id: 'golden_hour', label: 'Golden Hour', hint: 'Warm sunset amber rim' },
              { id: 'cyber_dusk', label: 'Cyber Dusk', hint: 'Neon twilight reflections' },
              { id: 'cinematic_moody', label: 'Cinematic Moody', hint: 'Dramatic directional shadow' },
            ].map((light) => {
              const active = lightingStyle === light.id;
              return (
                <button
                  key={light.id}
                  onClick={() => setLightingStyle(light.id as LightingStyle)}
                  className={`px-3 py-2 text-left rounded-lg border text-xs transition-all ${
                    active
                      ? 'border-stone-900 dark:border-stone-100 bg-stone-100 dark:bg-stone-800 text-stone-950 dark:text-stone-50 font-semibold'
                      : 'border-stone-200 dark:border-stone-800 bg-stone-50/40 dark:bg-stone-950 text-stone-600 dark:text-stone-400 hover:border-stone-300'
                  }`}
                >
                  <p className="font-medium text-stone-900 dark:text-stone-100">{light.label}</p>
                  <p className="text-[10px] text-stone-500 truncate">{light.hint}</p>
                </button>
              );
            })}
          </div>
        </div>

        {/* Aspect Ratio & Frame Geometry */}
        <div className="md:col-span-6 space-y-1.5">
          <label className="text-xs font-medium text-stone-700 dark:text-stone-300">
            Frame Aspect Ratio:
          </label>
          <div className="grid grid-cols-4 gap-2">
            {(['1:1', '16:9', '3:4', '4:3'] as AspectRatio[]).map((ratio) => {
              const active = aspectRatio === ratio;
              return (
                <button
                  key={ratio}
                  onClick={() => setAspectRatio(ratio)}
                  className={`py-3 px-2 text-center rounded-lg border text-xs font-mono tabular-nums transition-all ${
                    active
                      ? 'border-stone-900 dark:border-stone-100 bg-stone-100 dark:bg-stone-800 text-stone-950 dark:text-stone-50 font-bold'
                      : 'border-stone-200 dark:border-stone-800 bg-stone-50/40 dark:bg-stone-950 text-stone-600 dark:text-stone-400 hover:border-stone-300'
                  }`}
                >
                  <span>{ratio}</span>
                  <span className="block text-[10px] font-sans font-normal text-stone-400 mt-0.5">
                    {ratio === '1:1' ? 'Square' : ratio === '16:9' ? 'Wide' : ratio === '3:4' ? 'Portrait' : 'Standard'}
                  </span>
                </button>
              );
            })}
          </div>

          <div className="pt-2">
            <span className="text-[11px] text-stone-500 block">
              Gemini Nano Banana 2.1 will render pixel-accurate geometry formatted for the chosen medium.
            </span>
          </div>
        </div>
      </div>

      {/* Prompt Customization Area */}
      <div className="mt-5 pt-5 border-t border-stone-100 dark:border-stone-800">
        <label className="text-xs font-medium text-stone-700 dark:text-stone-300 block mb-1.5">
          {selectedMediumId === 'custom' ? 'Custom Marketing Medium Description:' : 'Medium Prompt Template (Editable):'}
        </label>
        <textarea
          value={customPrompt}
          onChange={(e) => setCustomPrompt(e.target.value)}
          rows={2}
          placeholder={
            selectedMediumId === 'custom'
              ? 'e.g., A brushed titanium sports thermos bottle resting on a tennis court bench, morning droplets...'
              : selectedMediumPreset?.defaultPrompt || ''
          }
          className="w-full text-xs p-3 rounded-lg border border-stone-200 dark:border-stone-700 bg-stone-50 dark:bg-stone-950 text-stone-800 dark:text-stone-200 focus:outline-none focus:ring-1 focus:ring-stone-400 dark:focus:ring-stone-600 resize-none font-sans"
        />

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mt-4">
          <p className="text-xs text-stone-500">
            Selected:{' '}
            <strong className="text-stone-800 dark:text-stone-200">
              {selectedMediumId === 'custom' ? 'Custom Medium' : selectedMediumPreset?.name}
            </strong>{' '}
            · Model:{' '}
            <span className="font-mono text-stone-700 dark:text-stone-300">gemini-nano-banana-2.1</span>
          </p>

          <button
            onClick={onSynthesize}
            disabled={isGenerating}
            className="px-5 py-2.5 text-xs font-semibold text-white bg-stone-900 dark:bg-stone-100 dark:text-stone-950 hover:bg-stone-800 dark:hover:bg-stone-200 rounded-lg transition-all flex items-center justify-center gap-2 disabled:opacity-50 shadow-sm"
          >
            <Sparkles className={`w-3.5 h-3.5 ${isGenerating ? 'animate-spin' : ''}`} />
            <span>
              {isGenerating
                ? 'Synthesizing Photorealistic Frame...'
                : `Synthesize Frame (${selectedMediumId === 'custom' ? 'Custom' : selectedMediumPreset?.name})`}
            </span>
          </button>
        </div>
      </div>
    </div>
  );
};
