import React, { useState } from 'react';
import { CampaignFrame } from '../types.ts';
import { Download, Sliders, Eye, Trash2, Copy, Check, Sparkles, ExternalLink } from 'lucide-react';
import JSZip from 'jszip';

interface FrameGalleryProps {
  frames: CampaignFrame[];
  onDeleteFrame: (id: string) => void;
  onClearAll: () => void;
  onSelectProductForInspection?: (frame: CampaignFrame) => void;
  originalImageBase64: string;
}

export const FrameGallery: React.FC<FrameGalleryProps> = ({
  frames,
  onDeleteFrame,
  onClearAll,
  originalImageBase64,
}) => {
  const [selectedFrame, setSelectedFrame] = useState<CampaignFrame | null>(null);
  const [sliderPos, setSliderPos] = useState<number>(50); // percentage 0-100 for comparison slider
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [isZipping, setIsZipping] = useState(false);

  // Single image download
  const handleDownloadSingle = (frame: CampaignFrame) => {
    const link = document.createElement('a');
    link.href = frame.imageUrl;
    link.download = `nanomock-${frame.mediumId}-${Date.now()}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Batch download using JSZip
  const handleDownloadAllZip = async () => {
    if (frames.length === 0) return;
    setIsZipping(true);
    try {
      const zip = new JSZip();
      const campaignFolder = zip.folder('nanomock-campaign-frames');

      // Add each frame
      frames.forEach((frame, idx) => {
        const base64Data = frame.imageUrl.replace(/^data:image\/[a-zA-Z0-9+.-]+;base64,/, '');
        campaignFolder?.file(`frame-${idx + 1}-${frame.mediumId}.png`, base64Data, { base64: true });
      });

      // Add campaign metadata summary json
      const metadata = {
        generatedAt: new Date().toISOString(),
        totalFrames: frames.length,
        model: 'gemini-nano-banana-2.1',
        frames: frames.map((f) => ({
          medium: f.mediumName,
          aspectRatio: f.aspectRatio,
          lighting: f.lightingStyle,
          prompt: f.prompt,
        })),
      };
      campaignFolder?.file('campaign-manifest.json', JSON.stringify(metadata, null, 2));

      const blob = await zip.generateAsync({ type: 'blob' });
      const link = document.createElement('a');
      link.href = URL.createObjectURL(blob);
      link.download = `nanomock-campaign-suite-${Date.now()}.zip`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(link.href);
    } catch (err) {
      console.error('Failed to generate ZIP:', err);
    } finally {
      setIsZipping(false);
    }
  };

  const handleCopyBase64 = (frame: CampaignFrame) => {
    navigator.clipboard.writeText(frame.imageUrl);
    setCopiedId(frame.id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="bg-white dark:bg-stone-900 rounded-xl border border-stone-200 dark:border-stone-800 p-6 shadow-xs">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-stone-100 dark:border-stone-800">
        <div>
          <h2 className="text-base font-semibold text-stone-900 dark:text-stone-100 font-display">
            03. Multi-Medium Campaign Frames
          </h2>
          <div className="flex items-center gap-2 text-xs text-stone-500 dark:text-stone-400 mt-1">
            <span>{frames.length} Frame{frames.length === 1 ? '' : 's'} Generated</span>
            <span aria-hidden="true">·</span>
            <span>Product Consistency Verified</span>
            <span aria-hidden="true">·</span>
            <span>Ready for Export</span>
          </div>
        </div>

        {frames.length > 0 && (
          <div className="flex items-center gap-2">
            <button
              onClick={handleDownloadAllZip}
              disabled={isZipping}
              className="px-3 py-1.5 text-xs font-medium text-stone-900 dark:text-stone-100 bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 rounded-lg transition-colors flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5" />
              <span>{isZipping ? 'Archiving ZIP...' : 'Download Suite (.ZIP)'}</span>
            </button>
            <button
              onClick={onClearAll}
              className="p-1.5 text-stone-400 hover:text-rose-600 rounded-lg transition-colors"
              title="Clear all frames"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>

      {frames.length === 0 ? (
        <div className="py-16 text-center flex flex-col items-center justify-center">
          <div className="w-12 h-12 rounded-xl bg-stone-100 dark:bg-stone-800 flex items-center justify-center text-stone-400 mb-3">
            <Sparkles className="w-6 h-6" />
          </div>
          <h3 className="text-sm font-semibold text-stone-900 dark:text-stone-100">
            No Marketing Frames Synthesized Yet
          </h3>
          <p className="text-xs text-stone-500 dark:text-stone-400 max-w-md mt-1 mb-4">
            Select a medium like Coffee Mugs, Billboards, or Heavyweight T-Shirts above and click
            "Synthesize Frame", or click "Generate 3-Medium Suite" in the header to visualize a coordinated campaign.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-6">
          {frames.map((frame) => (
            <div
              key={frame.id}
              className="group rounded-xl border border-stone-200 dark:border-stone-800 overflow-hidden bg-stone-50/50 dark:bg-stone-950 flex flex-col justify-between transition-all hover:border-stone-400 dark:hover:border-stone-700"
            >
              {/* Media Container */}
              <div
                className="relative aspect-square overflow-hidden bg-stone-100 dark:bg-stone-900 cursor-pointer"
                onClick={() => setSelectedFrame(frame)}
              >
                <img
                  src={frame.imageUrl}
                  alt={frame.mediumName}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover transition-transform group-hover:scale-[1.02] duration-300"
                />

                <div className="absolute inset-0 bg-stone-950/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setSelectedFrame(frame);
                    }}
                    className="p-2 rounded-lg bg-white/90 text-stone-900 hover:bg-white text-xs font-medium flex items-center gap-1 shadow-sm"
                  >
                    <Sliders className="w-3.5 h-3.5" />
                    <span>Compare & Zoom</span>
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      handleDownloadSingle(frame);
                    }}
                    className="p-2 rounded-lg bg-white/90 text-stone-900 hover:bg-white text-xs font-medium shadow-sm"
                    title="Download PNG"
                  >
                    <Download className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Frame Footer Info */}
              <div className="p-4 border-t border-stone-100 dark:border-stone-800 flex flex-col justify-between gap-3 flex-1">
                <div>
                  <div className="flex items-center justify-between">
                    <h4 className="text-sm font-semibold text-stone-900 dark:text-stone-100 font-display">
                      {frame.mediumName}
                    </h4>
                    <span className="text-[11px] font-mono text-stone-400 tabular-nums">
                      {frame.aspectRatio}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-stone-500 mt-1">
                    <span>{frame.lightingStyle.replace('_', ' ')}</span>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono text-[10px] text-stone-400">
                      {frame.usedModel.replace('gemini-', '')}
                    </span>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-stone-100 dark:border-stone-800/60">
                  <button
                    onClick={() => handleCopyBase64(frame)}
                    className="text-xs text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-100 flex items-center gap-1"
                  >
                    {copiedId === frame.id ? (
                      <>
                        <Check className="w-3.5 h-3.5 text-emerald-600" />
                        <span className="text-emerald-600 font-medium">Copied</span>
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        <span>Copy Base64</span>
                      </>
                    )}
                  </button>

                  <button
                    onClick={() => onDeleteFrame(frame.id)}
                    className="text-xs text-stone-400 hover:text-rose-600 transition-colors"
                  >
                    Remove
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Frame Comparison & Inspector Modal */}
      {selectedFrame && (
        <div
          className="fixed inset-0 z-50 bg-stone-950/70 backdrop-blur-sm flex items-center justify-center p-4 sm:p-6"
          onClick={() => setSelectedFrame(null)}
        >
          <div
            className="bg-white dark:bg-stone-900 rounded-2xl max-w-4xl w-full border border-stone-200 dark:border-stone-800 overflow-hidden shadow-2xl flex flex-col max-h-[90vh]"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Modal Header */}
            <div className="px-6 py-4 border-b border-stone-100 dark:border-stone-800 flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-stone-900 dark:text-stone-100 font-display">
                  Frame Consistency Inspector: {selectedFrame.mediumName}
                </h3>
                <p className="text-xs text-stone-500">
                  Drag the split slider to verify product details against the source anchor
                </p>
              </div>
              <button
                onClick={() => setSelectedFrame(null)}
                className="text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 text-sm font-semibold p-1"
              >
                ✕
              </button>
            </div>

            {/* Modal Body: Interactive Split-View Comparison Slider */}
            <div className="p-6 overflow-y-auto space-y-6">
              <div className="relative aspect-video rounded-xl overflow-hidden bg-stone-950 select-none border border-stone-800 shadow-inner">
                {/* Right side: Generated Mockup Medium */}
                <img
                  src={selectedFrame.imageUrl}
                  alt={selectedFrame.mediumName}
                  className="absolute inset-0 w-full h-full object-contain"
                />

                {/* Left side: Original Product Image clipped by slider position */}
                {originalImageBase64 && (
                  <div
                    className="absolute inset-y-0 left-0 overflow-hidden"
                    style={{ width: `${sliderPos}%` }}
                  >
                    <img
                      src={originalImageBase64}
                      alt="Original Product Anchor"
                      className="absolute inset-0 w-full h-full object-contain max-w-none"
                      style={{ width: '100%', height: '100%' }}
                    />
                    <div className="absolute top-3 left-3 bg-stone-900/80 text-white text-[11px] px-2 py-0.5 rounded backdrop-blur-xs font-mono">
                      Source Anchor
                    </div>
                  </div>
                )}

                <div className="absolute top-3 right-3 bg-stone-900/80 text-white text-[11px] px-2 py-0.5 rounded backdrop-blur-xs font-mono">
                  {selectedFrame.mediumName}
                </div>

                {/* Slider divider line and drag handle */}
                {originalImageBase64 && (
                  <div
                    className="absolute inset-y-0 w-0.5 bg-white shadow-lg pointer-events-none"
                    style={{ left: `${sliderPos}%` }}
                  >
                    <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-7 h-7 bg-white text-stone-900 rounded-full shadow-md flex items-center justify-center text-xs font-bold pointer-events-auto cursor-ew-resize">
                      ↔
                    </div>
                  </div>
                )}

                {/* Invisible input range for accessible sliding */}
                {originalImageBase64 && (
                  <input
                    type="range"
                    min="0"
                    max="100"
                    value={sliderPos}
                    onChange={(e) => setSliderPos(Number(e.target.value))}
                    className="absolute inset-0 w-full h-full opacity-0 cursor-ew-resize"
                  />
                )}
              </div>

              {/* Inspector Details */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
                <div className="p-3 rounded-lg bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800">
                  <span className="text-stone-400 block mb-1">Consistency Engine</span>
                  <span className="font-semibold text-stone-900 dark:text-stone-100 font-mono">
                    {selectedFrame.usedModel}
                  </span>
                </div>
                <div className="p-3 rounded-lg bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800">
                  <span className="text-stone-400 block mb-1">Frame Dimensions</span>
                  <span className="font-semibold text-stone-900 dark:text-stone-100 font-mono">
                    {selectedFrame.aspectRatio} Ratio
                  </span>
                </div>
                <div className="p-3 rounded-lg bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800">
                  <span className="text-stone-400 block mb-1">Lighting Preset</span>
                  <span className="font-semibold text-stone-900 dark:text-stone-100 capitalize">
                    {selectedFrame.lightingStyle.replace('_', ' ')}
                  </span>
                </div>
              </div>

              {/* Prompt Text */}
              <div className="p-3 rounded-lg bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800 text-xs">
                <span className="text-stone-400 block mb-1 font-medium">Generation Prompt:</span>
                <p className="text-stone-700 dark:text-stone-300 leading-relaxed font-mono text-[11px]">
                  {selectedFrame.prompt}
                </p>
              </div>
            </div>

            {/* Modal Actions */}
            <div className="px-6 py-4 border-t border-stone-100 dark:border-stone-800 flex items-center justify-between">
              <button
                onClick={() => handleCopyBase64(selectedFrame)}
                className="text-xs text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-100 flex items-center gap-1.5"
              >
                {copiedId === selectedFrame.id ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                    <span className="text-emerald-600">Copied to Clipboard</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>Copy Base64 Data URL</span>
                  </>
                )}
              </button>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => setSelectedFrame(null)}
                  className="px-4 py-2 text-xs font-medium text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800 rounded-lg transition-colors"
                >
                  Close
                </button>
                <button
                  onClick={() => handleDownloadSingle(selectedFrame)}
                  className="px-4 py-2 text-xs font-semibold text-white bg-stone-900 dark:bg-stone-100 dark:text-stone-950 hover:bg-stone-800 dark:hover:bg-stone-200 rounded-lg transition-colors flex items-center gap-1.5 shadow-sm"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Download High-Res PNG</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
