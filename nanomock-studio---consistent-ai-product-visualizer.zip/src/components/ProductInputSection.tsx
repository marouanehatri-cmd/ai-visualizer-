import React, { useRef, useState } from 'react';
import { Upload, Sparkles, Check, RefreshCw, AlertCircle } from 'lucide-react';
import { SampleProduct, ProductAnalysis } from '../types.ts';
import { SAMPLE_PRODUCTS } from '../data/sampleProducts.ts';

interface ProductInputSectionProps {
  currentImageBase64: string;
  setCurrentImageBase64: (base64: string) => void;
  selectedSample: SampleProduct | null;
  setSelectedSample: (sample: SampleProduct | null) => void;
  productAnalysis: ProductAnalysis | null;
  setProductAnalysis: (analysis: ProductAnalysis | null) => void;
  brandDetails: string;
  setBrandDetails: (details: string) => void;
}

export const ProductInputSection: React.FC<ProductInputSectionProps> = ({
  currentImageBase64,
  setCurrentImageBase64,
  selectedSample,
  setSelectedSample,
  productAnalysis,
  setProductAnalysis,
  brandDetails,
  setBrandDetails,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisError, setAnalysisError] = useState<string | null>(null);
  const [dragActive, setDragActive] = useState(false);

  // Convert image URL or file to base64
  const handleFileChange = (file: File) => {
    if (!file.type.startsWith('image/')) {
      setAnalysisError('Please upload an image file (PNG, JPG, WebP).');
      return;
    }
    const reader = new FileReader();
    reader.onload = (e) => {
      const base64 = e.target?.result as string;
      if (base64) {
        setCurrentImageBase64(base64);
        setSelectedSample(null);
        setProductAnalysis(null);
        setAnalysisError(null);
        // Automatically analyze uploaded product
        analyzeProductImage(base64, file.type);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragActive(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileChange(e.dataTransfer.files[0]);
    }
  };

  const handleSelectSample = async (sample: SampleProduct) => {
    setSelectedSample(sample);
    setAnalysisError(null);
    setBrandDetails(`${sample.name} (${sample.category}). ${sample.visualSummary}`);

    try {
      // Fetch local asset and convert to data URL base64
      const response = await fetch(sample.imagePath);
      const blob = await response.blob();
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64 = reader.result as string;
        setCurrentImageBase64(base64);
      };
      reader.readAsDataURL(blob);
    } catch (err) {
      console.error('Failed to convert sample image:', err);
    }
  };

  const analyzeProductImage = async (base64: string, mime: string = 'image/jpeg') => {
    setIsAnalyzing(true);
    setAnalysisError(null);
    try {
      const res = await fetch('/api/analyze-product', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ imageBase64: base64, mimeType: mime }),
      });
      const data = await res.json();
      if (!res.ok || data.error) {
        throw new Error(data.error || 'Failed to inspect product features');
      }
      setProductAnalysis(data.analysis);
      if (data.analysis?.visualIdentity) {
        setBrandDetails(
          `${data.analysis.productName || 'Product'}: ${data.analysis.visualIdentity}. Dominant colors: ${(data.analysis.dominantColors || []).join(', ')}`
        );
      }
    } catch (err: any) {
      console.warn('Product analysis warning:', err);
      setAnalysisError('Product loaded. Brand analysis can also be guided via text below.');
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <div className="bg-white dark:bg-stone-900 rounded-xl border border-stone-200 dark:border-stone-800 p-6 shadow-xs">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-5 border-b border-stone-100 dark:border-stone-800">
        <div>
          <h2 className="text-base font-semibold text-stone-900 dark:text-stone-100 font-display">
            01. Source Product Anchor
          </h2>
          <div className="flex items-center gap-2 text-xs text-stone-500 dark:text-stone-400 mt-1">
            <span>High-Fidelity Input</span>
            <span aria-hidden="true">·</span>
            <span>Nano Banana Consistency Lock</span>
            <span aria-hidden="true">·</span>
            <span>Multimodal Image-to-Image</span>
          </div>
        </div>

        {/* Quick select sample pills/buttons */}
        <div className="flex items-center gap-2 overflow-x-auto pb-1 sm:pb-0">
          <span className="text-xs text-stone-500 whitespace-nowrap">Sample Products:</span>
          {SAMPLE_PRODUCTS.map((prod) => {
            const isCurrent = selectedSample?.id === prod.id;
            return (
              <button
                key={prod.id}
                onClick={() => handleSelectSample(prod)}
                className={`text-xs px-2.5 py-1.5 rounded-lg border font-medium whitespace-nowrap transition-all ${
                  isCurrent
                    ? 'border-stone-900 dark:border-stone-100 bg-stone-900 text-white dark:bg-stone-100 dark:text-stone-900'
                    : 'border-stone-200 dark:border-stone-700 bg-stone-50 dark:bg-stone-800/60 text-stone-700 dark:text-stone-300 hover:border-stone-400'
                }`}
              >
                {prod.name.split(' ')[0]}
              </button>
            );
          })}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 mt-6 items-start">
        {/* Product Visual Display / Upload Dropzone */}
        <div className="lg:col-span-5">
          <div
            onDragOver={(e) => {
              e.preventDefault();
              setDragActive(true);
            }}
            onDragLeave={() => setDragActive(false)}
            onDrop={handleDrop}
            className={`relative aspect-square rounded-xl overflow-hidden border-2 transition-all group flex flex-col items-center justify-center bg-stone-50 dark:bg-stone-950 ${
              dragActive
                ? 'border-stone-900 dark:border-stone-100 bg-stone-100/50 dark:bg-stone-900/50'
                : 'border-dashed border-stone-300 dark:border-stone-700 hover:border-stone-400'
            }`}
          >
            {currentImageBase64 ? (
              <>
                <img
                  src={currentImageBase64}
                  alt={selectedSample ? selectedSample.name : 'Target Product'}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover transition-transform group-hover:scale-[1.02] duration-300"
                />
                <div className="absolute inset-0 bg-stone-950/40 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col items-center justify-center gap-2 p-4 text-center">
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="px-3.5 py-2 text-xs font-semibold text-stone-900 bg-white rounded-lg shadow-md hover:bg-stone-100 transition-colors whitespace-nowrap"
                  >
                    Change Product Image
                  </button>
                  <p className="text-[11px] text-white/90">or drop a new product photo</p>
                </div>
              </>
            ) : (
              <div
                onClick={() => fileInputRef.current?.click()}
                className="cursor-pointer p-6 text-center flex flex-col items-center"
              >
                <div className="w-12 h-12 rounded-full bg-stone-100 dark:bg-stone-800 flex items-center justify-center mb-3 text-stone-500 dark:text-stone-400 group-hover:scale-105 transition-transform">
                  <Upload className="w-5 h-5" />
                </div>
                <p className="text-sm font-semibold text-stone-900 dark:text-stone-100 mb-1">
                  Upload Product Image
                </p>
                <p className="text-xs text-stone-500 dark:text-stone-400 max-w-xs">
                  Drag & drop your product photo (PNG, JPG, WebP) or click to browse
                </p>
              </div>
            )}
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={(e) => {
                if (e.target.files?.[0]) handleFileChange(e.target.files[0]);
              }}
            />
          </div>

          <div className="flex items-center justify-between text-xs text-stone-500 mt-2 px-1">
            <span>Square 1:1 Recommended</span>
            <button
              onClick={() => fileInputRef.current?.click()}
              className="text-stone-700 dark:text-stone-300 hover:underline font-medium"
            >
              Upload custom photo
            </button>
          </div>
        </div>

        {/* Product Identity & Consistency Anchor Details */}
        <div className="lg:col-span-7 flex flex-col justify-between h-full space-y-4">
          <div>
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold uppercase tracking-wider text-stone-400 dark:text-stone-500">
                Visual Identity Specs
              </span>
              <button
                onClick={() => currentImageBase64 && analyzeProductImage(currentImageBase64)}
                disabled={isAnalyzing || !currentImageBase64}
                className="text-xs font-medium text-stone-700 dark:text-stone-300 hover:text-stone-950 dark:hover:text-white flex items-center gap-1.5 disabled:opacity-50"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isAnalyzing ? 'animate-spin' : ''}`} />
                <span>{isAnalyzing ? 'Analyzing with Gemini...' : 'Analyze Brand Details'}</span>
              </button>
            </div>

            <h3 className="text-lg font-bold text-stone-900 dark:text-stone-100 mt-1 font-display">
              {productAnalysis?.productName || selectedSample?.name || 'Selected Product Image'}
            </h3>

            <p className="text-xs text-stone-500 dark:text-stone-400 mt-1">
              {productAnalysis?.productCategory || selectedSample?.category || 'Commercial Product'} ·{' '}
              {productAnalysis?.recommendedTagline || selectedSample?.tagline || 'Ready for Mockups'}
            </p>

            {/* Dominant Colors */}
            <div className="mt-4">
              <span className="text-xs text-stone-500 dark:text-stone-400 block mb-1.5">
                Brand Palette Consistency Anchors:
              </span>
              <div className="flex items-center gap-3">
                {(productAnalysis?.dominantColors || selectedSample?.dominantColors || ['#1A1A1A', '#C5832B', '#E5D3B3']).map(
                  (col, idx) => (
                    <div key={idx} className="flex items-center gap-1.5 text-xs text-stone-600 dark:text-stone-300">
                      <span
                        className="w-4 h-4 rounded-md border border-stone-300 dark:border-stone-700 shrink-0 shadow-xs"
                        style={{ backgroundColor: col }}
                      />
                      <span className="font-mono tabular-nums text-[11px]">{col}</span>
                    </div>
                  )
                )}
              </div>
            </div>

            {/* Visual Consistency Guide text */}
            <div className="mt-4">
              <label className="text-xs font-medium text-stone-700 dark:text-stone-300 block mb-1.5">
                Consistency Directives (Nano Banana Prompt Guide):
              </label>
              <textarea
                value={brandDetails}
                onChange={(e) => setBrandDetails(e.target.value)}
                rows={3}
                placeholder="Describe key visual trademarks, logo shapes, materials, and typography to hold constant across frames..."
                className="w-full text-xs p-3 rounded-lg border border-stone-200 dark:border-stone-700 bg-stone-50 dark:bg-stone-950 text-stone-800 dark:text-stone-200 focus:outline-none focus:ring-1 focus:ring-stone-400 dark:focus:ring-stone-600 resize-none font-sans"
              />
              <p className="text-[11px] text-stone-500 mt-1">
                Nano Banana 2.1 will strictly cross-reference these physical attributes when rendering each marketing medium.
              </p>
            </div>
          </div>

          {analysisError && (
            <div className="flex items-center gap-2 p-2.5 rounded-lg bg-amber-50 dark:bg-amber-950/40 text-amber-800 dark:text-amber-200 text-xs border border-amber-200 dark:border-amber-900">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{analysisError}</span>
            </div>
          )}

          {/* Verification indicator */}
          <div className="flex items-center gap-2 text-xs text-stone-600 dark:text-stone-400 pt-2 border-t border-stone-100 dark:border-stone-800">
            <span className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-medium">
              <Check className="w-3.5 h-3.5" /> Product Anchor Ready
            </span>
            <span aria-hidden="true">·</span>
            <span>Input size: {currentImageBase64 ? 'Loaded in Memory' : 'None'}</span>
            <span aria-hidden="true">·</span>
            <span>Target mediums: 6 presets ready</span>
          </div>
        </div>
      </div>
    </div>
  );
};
