import React from 'react';
import { MEDIUM_PRESETS } from '../data/mediumPresets.ts';
import { MediumId, AspectRatio } from '../types.ts';
import { Coffee, Maximize2, Shirt, ShoppingBag, Train, Store, ArrowRight } from 'lucide-react';

interface MediumsPresetViewProps {
  onSelectMedium: (id: MediumId, aspect: AspectRatio) => void;
}

const MEDIUM_ICONS: Record<string, React.ReactNode> = {
  coffee_mug: <Coffee className="w-5 h-5" />,
  billboard: <Maximize2 className="w-5 h-5" />,
  t_shirt: <Shirt className="w-5 h-5" />,
  tote_bag: <ShoppingBag className="w-5 h-5" />,
  subway_poster: <Train className="w-5 h-5" />,
  storefront: <Store className="w-5 h-5" />,
};

export const MediumsPresetView: React.FC<MediumsPresetViewProps> = ({ onSelectMedium }) => {
  return (
    <div className="space-y-6">
      <div className="bg-white dark:bg-stone-900 rounded-xl border border-stone-200 dark:border-stone-800 p-6 shadow-xs">
        <div>
          <h2 className="text-base font-semibold text-stone-900 dark:text-stone-100 font-display">
            Commercial Marketing Medium Catalog
          </h2>
          <p className="text-xs text-stone-500 dark:text-stone-400 mt-1">
            Engineered prompts with physical light interaction, surface warping, and textile simulation for Gemini Nano Banana 2.1.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-6">
          {MEDIUM_PRESETS.map((preset) => (
            <div
              key={preset.id}
              className="p-5 rounded-xl border border-stone-200 dark:border-stone-800 bg-stone-50/50 dark:bg-stone-950 flex flex-col justify-between hover:border-stone-400 dark:hover:border-stone-700 transition-all"
            >
              <div>
                <div className="flex items-center justify-between mb-3">
                  <div className="w-9 h-9 rounded-lg bg-stone-100 dark:bg-stone-800 text-stone-700 dark:text-stone-300 flex items-center justify-center">
                    {MEDIUM_ICONS[preset.id]}
                  </div>
                  <span className="text-xs font-mono tabular-nums text-stone-400">
                    {preset.defaultAspect}
                  </span>
                </div>

                <h3 className="text-sm font-bold text-stone-900 dark:text-stone-100 font-display">
                  {preset.name}
                </h3>
                <p className="text-xs text-stone-500 mt-0.5">{preset.category}</p>
                <p className="text-xs text-stone-600 dark:text-stone-300 mt-2.5 leading-relaxed">
                  {preset.description}
                </p>

                <div className="mt-4 pt-3 border-t border-stone-100 dark:border-stone-800/80">
                  <span className="text-[11px] text-stone-400 block mb-1 font-medium">Prompt Archetype:</span>
                  <p className="text-[11px] font-mono text-stone-500 dark:text-stone-400 line-clamp-3 leading-normal">
                    {preset.defaultPrompt}
                  </p>
                </div>
              </div>

              <div className="mt-5 pt-3">
                <button
                  onClick={() => onSelectMedium(preset.id, preset.defaultAspect)}
                  className="w-full py-2 px-3 text-xs font-semibold rounded-lg bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-700 text-stone-900 dark:text-stone-100 hover:bg-stone-100 dark:hover:bg-stone-800 transition-colors flex items-center justify-center gap-1.5 shadow-2xs"
                >
                  <span>Select in Studio</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
