import React from 'react';
import { Sun, Moon, Sparkles, GitBranch } from 'lucide-react';

interface HeaderProps {
  activeTab: 'studio' | 'campaign' | 'mediums' | 'ci';
  setActiveTab: (tab: 'studio' | 'campaign' | 'mediums' | 'ci') => void;
  isDark: boolean;
  toggleTheme: () => void;
  onGenerateCampaign: () => void;
  isGenerating: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  isDark,
  toggleTheme,
  onGenerateCampaign,
  isGenerating,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-white/95 dark:bg-stone-900/95 backdrop-blur-md border-b border-stone-200 dark:border-stone-800 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Single text element wordmark in display face */}
        <button
          onClick={() => setActiveTab('studio')}
          className="text-xl font-bold tracking-tight text-stone-900 dark:text-stone-100 whitespace-nowrap shrink-0 text-left hover:opacity-85 transition-opacity font-display"
        >
          NanoMock Studio
        </button>

        {/* Zone 2: Concise single-line text navigation links */}
        <nav className="hidden md:flex items-center gap-7 text-sm font-medium">
          <button
            onClick={() => setActiveTab('studio')}
            className={`whitespace-nowrap shrink-0 transition-colors ${
              activeTab === 'studio'
                ? 'text-stone-950 dark:text-stone-50 font-semibold border-b-2 border-stone-900 dark:border-stone-100 pb-0.5'
                : 'text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-200'
            }`}
          >
            Visualizer Studio
          </button>
          <button
            onClick={() => setActiveTab('campaign')}
            className={`whitespace-nowrap shrink-0 transition-colors ${
              activeTab === 'campaign'
                ? 'text-stone-950 dark:text-stone-50 font-semibold border-b-2 border-stone-900 dark:border-stone-100 pb-0.5'
                : 'text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-200'
            }`}
          >
            Campaign Frames
          </button>
          <button
            onClick={() => setActiveTab('mediums')}
            className={`whitespace-nowrap shrink-0 transition-colors ${
              activeTab === 'mediums'
                ? 'text-stone-950 dark:text-stone-50 font-semibold border-b-2 border-stone-900 dark:border-stone-100 pb-0.5'
                : 'text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-200'
            }`}
          >
            Mediums Preset
          </button>
          <button
            onClick={() => setActiveTab('ci')}
            className={`whitespace-nowrap shrink-0 flex items-center gap-1.5 transition-colors ${
              activeTab === 'ci'
                ? 'text-stone-950 dark:text-stone-50 font-semibold border-b-2 border-stone-900 dark:border-stone-100 pb-0.5'
                : 'text-stone-600 dark:text-stone-400 hover:text-stone-900 dark:hover:text-stone-200'
            }`}
          >
            <GitBranch className="w-3.5 h-3.5" />
            GitHub Actions CI
          </button>
        </nav>

        {/* Zone 3: 1 primary action button + theme toggle */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={toggleTheme}
            aria-label="Toggle theme"
            className="p-2 text-stone-600 dark:text-stone-300 hover:text-stone-900 dark:hover:text-stone-100 hover:bg-stone-100 dark:hover:bg-stone-800 rounded-lg transition-colors"
          >
            {isDark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          </button>
          <button
            onClick={onGenerateCampaign}
            disabled={isGenerating}
            className="px-4 py-2 text-xs font-semibold text-white bg-stone-900 dark:bg-stone-100 dark:text-stone-950 hover:bg-stone-800 dark:hover:bg-stone-200 rounded-lg transition-colors flex items-center gap-2 disabled:opacity-50 whitespace-nowrap shadow-sm"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>{isGenerating ? 'Synthesizing...' : 'Generate 3-Medium Suite'}</span>
          </button>
        </div>
      </div>
    </header>
  );
};
