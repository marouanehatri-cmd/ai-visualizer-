import React, { useState, useEffect } from 'react';
import { GitBranch, CheckCircle2, Copy, Check, Terminal, ExternalLink, ShieldCheck, Download } from 'lucide-react';

export const GitHubActionsView: React.FC = () => {
  const [activeWorkflow, setActiveWorkflow] = useState<'ci' | 'deploy'>('ci');
  const [copied, setCopied] = useState(false);
  const [healthStatus, setHealthStatus] = useState<{
    status: string;
    hasApiKey: boolean;
    timestamp?: string;
  } | null>(null);
  const [checkingHealth, setCheckingHealth] = useState(false);

  useEffect(() => {
    checkHealth();
  }, []);

  const checkHealth = async () => {
    setCheckingHealth(true);
    try {
      const res = await fetch('/api/health');
      const data = await res.json();
      setHealthStatus(data);
    } catch {
      setHealthStatus({ status: 'offline', hasApiKey: false });
    } finally {
      setCheckingHealth(false);
    }
  };

  const ciYaml = `name: Continuous Integration

on:
  push:
    branches: [ main, master ]
  pull_request:
    branches: [ main, master ]
  workflow_dispatch:

concurrency:
  group: \${{ github.workflow }}-\${{ github.ref }}
  cancel-in-progress: true

jobs:
  lint-and-build:
    name: Lint, Test & Build
    runs-on: ubuntu-latest

    strategy:
      matrix:
        node-version: [20.x, 22.x]

    steps:
      - name: Checkout repository
        uses: actions/checkout@v4

      - name: Setup Node.js \${{ matrix.node-version }}
        uses: actions/setup-node@v4
        with:
          node-version: \${{ matrix.node-version }}
          cache: 'npm'

      - name: Install dependencies
        run: npm ci

      - name: Validate TypeScript & Linting
        run: npm run lint

      - name: Verify Environment Example
        run: |
          if [ ! -f .env.example ]; then
            echo "Missing .env.example file!"
            exit 1
          fi
          echo ".env.example verified successfully"

      - name: Build Application
        run: npm run build
        env:
          NODE_ENV: production

      - name: Verify Production Assets
        run: |
          if [ ! -d dist ]; then
            echo "Build output dist directory missing!"
            exit 1
          fi
          ls -la dist/
          echo "Production build verified successfully"

      - name: Upload Build Artifacts
        if: matrix.node-version == '22.x'
        uses: actions/upload-artifact@v4
        with:
          name: nanomock-studio-dist
          path: dist/
          retention-days: 7`;

  const deployYaml = `name: Production Build & Release

on:
  push:
    tags:
      - 'v*'
  workflow_dispatch:

jobs:
  build-and-package:
    name: Build & Package Applet
    runs-on: ubuntu-latest
    steps:
      - name: Checkout repository
        uses: actions/checkout@v4

      - name: Setup Node.js 22
        uses: actions/setup-node@v4
        with:
          node-version: 22.x
          cache: 'npm'

      - name: Install dependencies
        run: npm ci

      - name: Compile and Build Applet
        run: npm run build
        env:
          NODE_ENV: production
          GEMINI_API_KEY: \${{ secrets.GEMINI_API_KEY }}

      - name: Verify Distribution
        run: |
          test -d dist && test -f dist/index.html
          echo "Build integrity validated"

      - name: Create Release Archive
        run: |
          tar -czvf release-build.tar.gz dist/ package.json server.ts
        
      - name: Archive Production Release
        uses: actions/upload-artifact@v4
        with:
          name: nanomock-release-\${{ github.sha }}
          path: release-build.tar.gz
          retention-days: 14`;

  const currentYaml = activeWorkflow === 'ci' ? ciYaml : deployYaml;

  const handleCopy = () => {
    navigator.clipboard.writeText(currentYaml);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadWorkflow = () => {
    const filename = activeWorkflow === 'ci' ? 'ci.yml' : 'deploy.yml';
    const blob = new Blob([currentYaml], { type: 'text/yaml' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(link.href);
  };

  return (
    <div className="space-y-6">
      {/* Overview & Status Strip */}
      <div className="bg-white dark:bg-stone-900 rounded-xl border border-stone-200 dark:border-stone-800 p-6 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-5 border-b border-stone-100 dark:border-stone-800">
          <div>
            <h2 className="text-base font-semibold text-stone-900 dark:text-stone-100 font-display">
              GitHub Actions Automation Suite
            </h2>
            <div className="flex items-center gap-2 text-xs text-stone-500 dark:text-stone-400 mt-1">
              <span>Continuous Integration</span>
              <span aria-hidden="true">·</span>
              <span>Matrix Node 20 & 22</span>
              <span aria-hidden="true">·</span>
              <span>Artifact Distribution</span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={checkHealth}
              disabled={checkingHealth}
              className="text-xs px-3 py-1.5 rounded-lg border border-stone-200 dark:border-stone-700 bg-stone-50 dark:bg-stone-800 text-stone-700 dark:text-stone-300 hover:bg-stone-100"
            >
              {checkingHealth ? 'Checking...' : 'Check Server CI Endpoint'}
            </button>
            <div className="flex items-center gap-1.5 text-xs text-emerald-600 dark:text-emerald-400 font-medium">
              <CheckCircle2 className="w-4 h-4" />
              <span>CI Configured & Ready</span>
            </div>
          </div>
        </div>

        {/* CI Diagnostics Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-6">
          <div className="p-4 rounded-lg bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800">
            <span className="text-xs text-stone-400 block mb-1">Workflow Location</span>
            <p className="text-xs font-mono font-semibold text-stone-900 dark:text-stone-100">
              .github/workflows/ci.yml
            </p>
            <span className="text-[11px] text-stone-500 block mt-1">
              Auto-triggers on push & PR to main/master
            </span>
          </div>

          <div className="p-4 rounded-lg bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800">
            <span className="text-xs text-stone-400 block mb-1">TypeScript & Build Checks</span>
            <p className="text-xs font-mono font-semibold text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
              <Check className="w-3.5 h-3.5" /> npm run lint + npm run build
            </p>
            <span className="text-[11px] text-stone-500 block mt-1">
              Strict compilation validation in pipeline
            </span>
          </div>

          <div className="p-4 rounded-lg bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800">
            <span className="text-xs text-stone-400 block mb-1">Gemini API Secret Ingestion</span>
            <p className="text-xs font-mono font-semibold text-stone-900 dark:text-stone-100">
              ${'{' + '{ secrets.GEMINI_API_KEY }' + '}'}
            </p>
            <span className="text-[11px] text-stone-500 block mt-1">
              Repository Secrets mapped to build environment
            </span>
          </div>
        </div>
      </div>

      {/* Workflow File Viewer */}
      <div className="bg-white dark:bg-stone-900 rounded-xl border border-stone-200 dark:border-stone-800 p-6 shadow-xs">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-stone-100 dark:border-stone-800">
          <div className="flex items-center gap-2">
            <button
              onClick={() => setActiveWorkflow('ci')}
              className={`text-xs px-3 py-1.5 rounded-lg border font-medium transition-all ${
                activeWorkflow === 'ci'
                  ? 'border-stone-900 dark:border-stone-100 bg-stone-900 text-white dark:bg-stone-100 dark:text-stone-900'
                  : 'border-stone-200 dark:border-stone-700 bg-stone-50 dark:bg-stone-800 text-stone-600 dark:text-stone-400 hover:text-stone-900'
              }`}
            >
              ci.yml (Test & Build Matrix)
            </button>
            <button
              onClick={() => setActiveWorkflow('deploy')}
              className={`text-xs px-3 py-1.5 rounded-lg border font-medium transition-all ${
                activeWorkflow === 'deploy'
                  ? 'border-stone-900 dark:border-stone-100 bg-stone-900 text-white dark:bg-stone-100 dark:text-stone-900'
                  : 'border-stone-200 dark:border-stone-700 bg-stone-50 dark:bg-stone-800 text-stone-600 dark:text-stone-400 hover:text-stone-900'
              }`}
            >
              deploy.yml (Release Tarball)
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleCopy}
              className="px-3 py-1.5 text-xs font-medium text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800 rounded-lg transition-colors flex items-center gap-1.5"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied' : 'Copy YAML'}</span>
            </button>
            <button
              onClick={handleDownloadWorkflow}
              className="px-3 py-1.5 text-xs font-semibold text-white bg-stone-900 dark:bg-stone-100 dark:text-stone-950 hover:bg-stone-800 dark:hover:bg-stone-200 rounded-lg transition-colors flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download File</span>
            </button>
          </div>
        </div>

        {/* Code Block */}
        <div className="mt-4 rounded-xl overflow-hidden bg-stone-950 text-stone-200 p-4 font-mono text-xs leading-relaxed overflow-x-auto border border-stone-800 max-h-96">
          <pre>{currentYaml}</pre>
        </div>
      </div>

      {/* GitHub Repository Setup Guide */}
      <div className="bg-white dark:bg-stone-900 rounded-xl border border-stone-200 dark:border-stone-800 p-6 shadow-xs">
        <h3 className="text-sm font-semibold text-stone-900 dark:text-stone-100 font-display mb-3">
          Setting Up with Your GitHub Repository
        </h3>
        <ol className="list-decimal list-inside space-y-2 text-xs text-stone-600 dark:text-stone-400 leading-relaxed">
          <li>
            Push this codebase to your GitHub repository (the{' '}
            <code className="text-stone-900 dark:text-stone-100 font-mono">.github/workflows</code>{' '}
            folder is already included).
          </li>
          <li>
            In GitHub, navigate to{' '}
            <strong className="text-stone-900 dark:text-stone-100">
              Settings &gt; Secrets and variables &gt; Actions
            </strong>
            .
          </li>
          <li>
            Click{' '}
            <strong className="text-stone-900 dark:text-stone-100">New repository secret</strong>{' '}
            and name it <code className="font-mono text-stone-900 dark:text-stone-100">GEMINI_API_KEY</code>.
          </li>
          <li>
            Paste your Google AI Studio API key into the value field and save.
          </li>
          <li>
            Any subsequent <code className="font-mono">git push</code> will trigger the CI pipeline,
            linting code and creating verified production build artifacts automatically!
          </li>
        </ol>
      </div>
    </div>
  );
};
