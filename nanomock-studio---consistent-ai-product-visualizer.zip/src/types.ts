export type MediumId =
  | 'coffee_mug'
  | 'billboard'
  | 't_shirt'
  | 'tote_bag'
  | 'subway_poster'
  | 'storefront'
  | 'custom';

export type AspectRatio = '1:1' | '16:9' | '4:3' | '3:4' | '9:16';
export type LightingStyle = 'studio' | 'golden_hour' | 'cyber_dusk' | 'cinematic_moody';

export interface MediumPreset {
  id: MediumId;
  name: string;
  category: string;
  defaultAspect: AspectRatio;
  description: string;
  defaultPrompt: string;
}

export interface SampleProduct {
  id: string;
  name: string;
  category: string;
  tagline: string;
  imagePath: string;
  dominantColors: string[];
  materials: string;
  visualSummary: string;
}

export interface ProductAnalysis {
  productName?: string;
  productCategory?: string;
  visualIdentity?: string;
  dominantColors?: string[];
  recommendedTagline?: string;
  mediumPrompts?: Record<string, string>;
}

export interface CampaignFrame {
  id: string;
  mediumId: MediumId;
  mediumName: string;
  imageUrl: string;
  originalImage: string;
  aspectRatio: AspectRatio;
  prompt: string;
  timestamp: number;
  usedModel: string;
  lightingStyle: LightingStyle;
}
