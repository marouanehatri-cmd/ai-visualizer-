/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Header } from './components/Header.tsx';
import { ProductInputSection } from './components/ProductInputSection.tsx';
import { MediumSelector } from './components/MediumSelector.tsx';
import { FrameGallery } from './components/FrameGallery.tsx';
import { MediumsPresetView } from './components/MediumsPresetView.tsx';
import { GitHubActionsView } from './components/GitHubActionsView.tsx';
import { SAMPLE_PRODUCTS } from './data/sampleProducts.ts';
import { MEDIUM_PRESETS } from './data/mediumPresets.ts';
import {
  MediumId,
  AspectRatio,
  LightingStyle,
  SampleProduct,
  ProductAnalysis,
  CampaignFrame,
} from './types.ts';
import { AlertCircle, CheckCircle2, Sparkles } from 'lucide-react';

export default function App() {
  const [isDark, setIsDark] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      return (
        localStorage.getItem('nanomock_theme') === 'dark' ||
        window.matchMedia('(prefers-color-scheme: dark)').matches
      );
    }
    return false;
  });

  const [activeTab, setActiveTab] = useState<'studio' | 'campaign' | 'mediums' | 'ci'>('studio');
  const [selectedSample, setSelectedSample] = useState<SampleProduct | null>(SAMPLE_PRODUCTS[0]);
  const [currentImageBase64, setCurrentImageBase64] = useState<string>('');
  const [productAnalysis, setProductAnalysis] = useState<ProductAnalysis | null>(null);
  const [brandDetails, setBrandDetails] = useState<string>(
    'Artisan Coffee Roasters (Ethiopia Yirgacheffe). Geometric bronze coffee bean crest, minimalist matte black pouch.'
  );

  const [selectedMediumId, setSelectedMediumId] = useState<MediumId>('coffee_mug');
  const [customPrompt, setCustomPrompt] = useState<string>('');
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>('1:1');
  const [lightingStyle, setLightingStyle] = useState<LightingStyle>('studio');
  const [quality, setQuality] = useState<'1K' | '2K'>('1K');

  const [frames, setFrames] = useState<CampaignFrame[]>([]);
  const [isGenerating, setIsGenerating] = useState<boolean>(false);
  const [notification, setNotification] = useState<{
    type: 'success' | 'error' | 'info';
    message: string;
  } | null>(null);

  // Sync theme
  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('nanomock_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('nanomock_theme', 'light');
    }
  }, [isDark]);

  // Load initial sample product on mount
  useEffect(() => {
    const loadInitialProduct = async () => {
      try {
        const response = await fetch(SAMPLE_PRODUCTS[0].imagePath);
        const blob = await response.blob();
        const reader = new FileReader();
        reader.onloadend = () => {
          setCurrentImageBase64(reader.result as string);
        };
        reader.readAsDataURL(blob);
      } catch (err) {
        console.error('Failed to load initial sample:', err);
      }
    };
    loadInitialProduct();
  }, []);

  const toggleTheme = () => setIsDark((prev) => !prev);

  const showNotification = (type: 'success' | 'error' | 'info', message: string) => {
    setNotification({ type, message });
    setTimeout(() => {
      setNotification((curr) => (curr?.message === message ? null : curr));
    }, 5000);
  };

  const selectedPreset = MEDIUM_PRESETS.find((p) => p.id === selectedMediumId);

  // Synthesize single frame
  const handleSynthesizeSingleFrame = async () => {
    if (!currentImageBase64) {
      showNotification('error', 'Please select or upload a product image first.');
      return;
    }

    setIsGenerating(true);
    showNotification('info', `Synthesizing ${selectedPreset?.name || 'custom medium'} with Gemini Nano Banana...`);

    try {
      const response = await fetch('/api/visualize', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: currentImageBase64,
          mediumId: selectedMediumId,
          customPrompt: customPrompt || (selectedPreset ? selectedPreset.defaultPrompt : ''),
          aspectRatio,
          quality,
          lightingStyle,
          brandDetails,
        }),
      });

      const data = await response.json();
      if (!response.ok || data.error) {
        throw new Error(data.error || 'Visualization synthesis failed');
      }

      const newFrame: CampaignFrame = {
        id: `frame_${Date.now()}`,
        mediumId: selectedMediumId,
        mediumName: selectedMediumId === 'custom' ? 'Custom Medium' : selectedPreset?.name || 'Marketing Medium',
        imageUrl: data.imageUrl,
        originalImage: currentImageBase64,
        aspectRatio,
        prompt: customPrompt || selectedPreset?.defaultPrompt || '',
        timestamp: Date.now(),
        usedModel: data.usedModel || 'gemini-nano-banana-2.1',
        lightingStyle,
      };

      setFrames((prev) => [newFrame, ...prev]);
      showNotification('success', `Frame generated with locked product consistency using ${data.usedModel}!`);
      // Switch view to campaign frames
      setActiveTab('campaign');
    } catch (err: any) {
      console.error('Synthesis error:', err);
      showNotification('error', err.message || 'Generation failed. Check your API key or network.');
    } finally {
      setIsGenerating(false);
    }
  };

  // Generate full 3-medium campaign suite (Coffee Mug, Billboard, T-Shirt)
  const handleGenerateCampaignSuite = async () => {
    if (!currentImageBase64) {
      showNotification('error', 'Please select or upload a product image first.');
      return;
    }

    setIsGenerating(true);
    showNotification('info', 'Generating complete 3-medium campaign suite (Mug + Billboard + T-Shirt)...');

    try {
      const suiteMediums: MediumId[] = ['coffee_mug', 'billboard', 't_shirt'];
      const response = await fetch('/api/campaign-suite', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: currentImageBase64,
          mediumIds: suiteMediums,
          brandDetails,
          lightingStyle,
        }),
      });

      const data = await response.json();
      if (!response.ok || data.error) {
        throw new Error(data.error || 'Failed to generate campaign suite');
      }

      const newFrames: CampaignFrame[] = [];
      for (const item of data.frames || []) {
        if (item.imageUrl) {
          const preset = MEDIUM_PRESETS.find((p) => p.id === item.mediumId);
          newFrames.push({
            id: `suite_${item.mediumId}_${Date.now()}`,
            mediumId: item.mediumId,
            mediumName: preset?.name || item.mediumId,
            imageUrl: item.imageUrl,
            originalImage: currentImageBase64,
            aspectRatio: (item.aspectRatio as AspectRatio) || '1:1',
            prompt: preset?.defaultPrompt || '',
            timestamp: Date.now(),
            usedModel: 'gemini-nano-banana-2.1',
            lightingStyle,
          });
        }
      }

      if (newFrames.length > 0) {
        setFrames((prev) => [...newFrames, ...prev]);
        showNotification('success', `Successfully generated ${newFrames.length} consistent campaign frames!`);
        setActiveTab('campaign');
      } else {
        throw new Error('No images returned in the campaign suite');
      }
    } catch (err: any) {
      console.error('Suite error:', err);
      showNotification('error', err.message || 'Failed to synthesize campaign suite.');
    } finally {
      setIsGenerating(false);
    }
  };

  const handleDeleteFrame = (id: string) => {
    setFrames((prev) => prev.filter((f) => f.id !== id));
  };

  const handleClearAll = () => {
    if (confirm('Clear all campaign frames?')) {
      setFrames([]);
    }
  };

  return (
    <div className="min-h-screen bg-stone-50 dark:bg-stone-950 text-stone-900 dark:text-stone-100 flex flex-col font-sans transition-colors">
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        isDark={isDark}
        toggleTheme={toggleTheme}
        onGenerateCampaign={handleGenerateCampaignSuite}
        isGenerating={isGenerating}
      />

      {/* Floating Notification */}
      {notification && (
        <div className="fixed bottom-6 right-6 z-50 max-w-md animate-fade-in">
          <div
            className={`p-3.5 rounded-xl border shadow-lg flex items-center gap-2.5 text-xs font-medium ${
              notification.type === 'success'
                ? 'bg-emerald-50 dark:bg-emerald-950 text-emerald-900 dark:text-emerald-100 border-emerald-300 dark:border-emerald-800'
                : notification.type === 'error'
                ? 'bg-rose-50 dark:bg-rose-950 text-rose-900 dark:text-rose-100 border-rose-300 dark:border-rose-800'
                : 'bg-stone-900 text-white dark:bg-stone-100 dark:text-stone-950 border-stone-700'
            }`}
          >
            {notification.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            ) : notification.type === 'error' ? (
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            ) : (
              <Sparkles className="w-4 h-4 shrink-0 animate-spin" />
            )}
            <span className="flex-1">{notification.message}</span>
            <button
              onClick={() => setNotification(null)}
              className="text-stone-400 hover:text-stone-600 ml-1"
            >
              ✕
            </button>
          </div>
        </div>
      )}

      {/* Main Workspace Content */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        {/* Studio View */}
        {activeTab === 'studio' && (
          <div className="space-y-8">
            {/* Step 1: Source Product Input & Inspection */}
            <ProductInputSection
              currentImageBase64={currentImageBase64}
              setCurrentImageBase64={setCurrentImageBase64}
              selectedSample={selectedSample}
              setSelectedSample={setSelectedSample}
              productAnalysis={productAnalysis}
              setProductAnalysis={setProductAnalysis}
              brandDetails={brandDetails}
              setBrandDetails={setBrandDetails}
            />

            {/* Step 2: Medium Selection & Environmental Controls */}
            <MediumSelector
              selectedMediumId={selectedMediumId}
              setSelectedMediumId={setSelectedMediumId}
              customPrompt={customPrompt}
              setCustomPrompt={setCustomPrompt}
              aspectRatio={aspectRatio}
              setAspectRatio={setAspectRatio}
              lightingStyle={lightingStyle}
              setLightingStyle={setLightingStyle}
              quality={quality}
              setQuality={setQuality}
              onSynthesize={handleSynthesizeSingleFrame}
              isGenerating={isGenerating}
              selectedMediumPreset={selectedPreset}
            />

            {/* Step 3: Frames Gallery */}
            <FrameGallery
              frames={frames}
              onDeleteFrame={handleDeleteFrame}
              onClearAll={handleClearAll}
              originalImageBase64={currentImageBase64}
            />
          </div>
        )}

        {/* Campaign Frames Dedicated View */}
        {activeTab === 'campaign' && (
          <div className="space-y-6">
            <FrameGallery
              frames={frames}
              onDeleteFrame={handleDeleteFrame}
              onClearAll={handleClearAll}
              originalImageBase64={currentImageBase64}
            />
          </div>
        )}

        {/* Mediums Preset Catalog View */}
        {activeTab === 'mediums' && (
          <MediumsPresetView
            onSelectMedium={(id, aspect) => {
              setSelectedMediumId(id);
              setAspectRatio(aspect);
              setActiveTab('studio');
            }}
          />
        )}

        {/* GitHub Actions Automation View */}
        {activeTab === 'ci' && <GitHubActionsView />}
      </main>

      {/* Footer conforming to Anti-Slop section §1.B */}
      <footer className="border-t border-stone-200 dark:border-stone-800 bg-white dark:bg-stone-900 transition-colors py-6 text-xs text-stone-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p>
            NanoMock Studio · Consistent Commercial Marketing Mediums with Gemini Nano Banana
          </p>
          <div className="flex items-center gap-6">
            <button
              onClick={() => setActiveTab('ci')}
              className="hover:text-stone-900 dark:hover:text-stone-100 transition-colors"
            >
              GitHub Actions (.github/workflows)
            </button>
            <button
              onClick={() => setActiveTab('mediums')}
              className="hover:text-stone-900 dark:hover:text-stone-100 transition-colors"
            >
              Marketing Presets
            </button>
            <button
              onClick={() => setActiveTab('studio')}
              className="hover:text-stone-900 dark:hover:text-stone-100 transition-colors"
            >
              Visualizer Studio
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
