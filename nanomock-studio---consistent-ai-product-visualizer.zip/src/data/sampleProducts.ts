import { SampleProduct } from '../types.ts';

export const SAMPLE_PRODUCTS: SampleProduct[] = [
  {
    id: 'coffee_bag',
    name: 'Artisan Coffee Roasters',
    category: 'Specialty Beverage',
    tagline: 'Ethiopia Yirgacheffe Single Origin',
    imagePath: '/src/assets/images/sample_coffee_bag_1793473218407.jpg',
    dominantColors: ['#1A1A1A', '#C5832B', '#E5D3B3'],
    materials: 'Matte black foil pouch with metallic bronze foil stamping',
    visualSummary: 'Geometric coffee bean crest in polished bronze, serif typography, minimalist matte pouch with tactile zipper seal.',
  },
  {
    id: 'skincare_serum',
    name: 'Lumen Botanics Radiance Boost',
    category: 'Clean Skincare & Beauty',
    tagline: 'Vitamin C + Hyaluronic Acid Infusion',
    imagePath: '/src/assets/images/sample_skincare_serum_1793473219122.jpg',
    dominantColors: ['#7A4B1A', '#F7F6F2', '#222222'],
    materials: 'Amber pharmaceutical glass bottle with textured paper label and matte black dropper pipette',
    visualSummary: 'Clean modern apothecary aesthetic, amber bottle glass, crisp black sans-serif typography on organic textured ivory stock.',
  },
  {
    id: 'beverage_can',
    name: 'Volt Sparkling Energy',
    category: 'Functional Beverage',
    tagline: 'Electric Lime Citrus Refreshment',
    imagePath: '/src/assets/images/sample_beverage_can_1793473220405.jpg',
    dominantColors: ['#A6E22E', '#111315', '#FFFFFF'],
    materials: 'Matte gunmetal aluminum can with gloss neon green screen-print and chilled moisture beads',
    visualSummary: 'Electric split-lightning bolt emblem, high-contrast neon chartreuse and tactical carbon grey, bold condensed athletics typography.',
  },
  {
    id: 'headphones',
    name: 'Aeterna Studio Wireless',
    category: 'High-Fidelity Audio',
    tagline: 'Precision Acoustic Engineering',
    imagePath: '/src/assets/images/sample_headphones_1793473221184.jpg',
    dominantColors: ['#F2EFE9', '#9C968D', '#2B2B28'],
    materials: 'Brushed aerospace titanium headband with supple pearl white vegan memory leather',
    visualSummary: 'Sculpted acoustic earcups with debossed micro-lettering, champagne brushed metallic pivot brackets, minimalist Scandinavian form.',
  },
];
