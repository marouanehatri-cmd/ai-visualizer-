import { MediumPreset } from '../types.ts';

export const MEDIUM_PRESETS: MediumPreset[] = [
  {
    id: 'coffee_mug',
    name: 'Ceramic Coffee Mug',
    category: 'Tabletop & Drinkware',
    defaultAspect: '1:1',
    description: 'Cafe morning scene with soft window light and ceramic wrap projection.',
    defaultPrompt:
      'A premium ceramic coffee mug resting on a natural white oak cafe table in morning sunlight, steam gently rising. The exact product logo, typography, and visual branding from the input image is photorealistically printed and seamlessly wrapped around the ceramic surface with realistic glaze reflections and depth.',
  },
  {
    id: 'billboard',
    name: 'Metropolitan Billboard',
    category: 'Out of Home (OOH)',
    defaultAspect: '16:9',
    description: 'Towering highway billboard at dusk with spotlight beam illumination.',
    defaultPrompt:
      'A massive towering metropolitan outdoor highway billboard elevated above an urban avenue at dusk. Cinematic blue hour sky, illuminated by warm overhead billboard spotlights, city traffic bokeh below. The billboard poster prominently showcases the exact product packaging and visual brand identity with razor-sharp typography.',
  },
  {
    id: 't_shirt',
    name: 'Heavyweight Cotton T-Shirt',
    category: 'Apparel & Streetwear',
    defaultAspect: '3:4',
    description: 'Streetwear garment in a sunlit industrial loft with screen-print texture.',
    defaultPrompt:
      'A stylish fashion model wearing an oversized heavyweight vintage-washed charcoal black cotton t-shirt in a sunlit industrial loft studio. The exact product graphic, emblem, and brand logo from the input image is crisp and authentically screen-printed onto the chest with natural fabric wrinkles and soft textile weave texture.',
  },
  {
    id: 'tote_bag',
    name: 'Canvas Tote Bag',
    category: 'Retail & Lifestyle',
    defaultAspect: '1:1',
    description: 'Organic unbleached canvas tote hanging in a design boutique.',
    defaultPrompt:
      'An aesthetic unbleached natural organic canvas tote bag hanging gracefully on a wooden wall peg inside a boutique design shop. The product branding and primary artwork from the input image is cleanly screen-printed onto the canvas, showing realistic coarse woven cotton texture and gentle draped fabric folds.',
  },
  {
    id: 'subway_poster',
    name: 'Subway Lightbox Poster',
    category: 'Transit Advertising',
    defaultAspect: '16:9',
    description: 'Underground transit lightbox with architectural lighting.',
    defaultPrompt:
      'An ultra-modern illuminated backlit transit lightbox poster on the tiled wall of a minimalist underground subway station. Gentle cinematic passenger motion blur in the background, cool architectural lighting. The advertisement vividly displays the exact product design and brand typography in commercial clarity.',
  },
  {
    id: 'storefront',
    name: 'Luxury Storefront Window',
    category: 'Retail Architecture',
    defaultAspect: '4:3',
    description: '5th Avenue style boutique window with sculpted pedestal.',
    defaultPrompt:
      'A high-end luxury boutique display window along an upscale metropolitan shopping avenue. The product is elegantly spotlighted on a sculpted travertine pedestal behind pristine reflective plate glass, with subtle boutique interior ambiance and architectural mood lighting.',
  },
];
