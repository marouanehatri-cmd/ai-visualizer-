# NanoMock Studio — Consistent AI Product Visualizer

> Visualize any product image across diverse commercial marketing mediums—ceramic coffee mugs, metropolitan billboards, apparel, tote bags, transit posters, and boutique storefronts—with locked product consistency powered by Gemini Nano Banana 2.1.

## GitHub Actions Ready

This repository includes turnkey GitHub Actions workflows:

- **`.github/workflows/ci.yml`**: Automatically triggered on every push and pull request to `main` and `master`. Executes TypeScript type-checks, code linting, and full production asset builds across Node.js versions (v20, v22).
- **`.github/workflows/deploy.yml`**: Production packaging and release artifact generation on version tags (`v*`) or manual triggers via GitHub dispatch.

### Setting up GitHub Actions Secrets

To enable full end-to-end integration testing in your GitHub repository:
1. Navigate to your GitHub repository: **Settings > Secrets and variables > Actions**.
2. Click **New repository secret**.
3. Add `GEMINI_API_KEY` with your Google AI Studio API key.

## Key Features

1. **Product Consistency Lock (Nano Banana 2.1)**:
   - Uses multimodal image-to-image synthesis to lock the product's exact typography, label art, color palette, packaging geometries, and physical materials across every medium.
   - Intelligent fallback to `gemini-3.1-flash-lite-image` if quota restrictions occur.

2. **Diverse Commercial Mediums**:
   - **Ceramic Coffee Mug**: Curved wrap projection with realistic glaze highlights on cafe oak.
   - **Metropolitan Billboard**: Large-scale outdoor OOH installation at dusk with spotlight beams and city light bokeh.
   - **Heavyweight Cotton T-Shirt**: Streetwear garment with realistic screen-print ink absorption and fabric draping.
   - **Canvas Tote Bag**: Organic woven cotton bag with subtle boutique lighting.
   - **Subway Station Lightbox**: Transit poster in an architectural transit hall with motion blur.
   - **Luxury Storefront Window**: Pedestal display behind reflective plate glass on an upscale boulevard.
   - **Custom Medium**: Free-form prompt targeting any commercial medium or ambient lighting condition.

3. **Multi-Frame Campaign Suites**:
   - Coordinated generation of matching marketing assets in one batch.
   - Interactive side-by-side comparison slider (Original vs. Marketing Mockup).
   - Instant 1-click batch ZIP download of all high-resolution campaign frames.

4. **Developer & CI/CD Hub**:
   - Live GitHub Actions status inspector, workflow YAML previews, and one-click copyable configuration.
